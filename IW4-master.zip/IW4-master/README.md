# IW4
Raw MW2 .GSC files and .MENU files. No FastFiles.


# Raw Files
Raw files are the code snippets that make up the game's basic logic. These are the .GSC files inside of the CoD series'
custom archive format, FastFile. .CFG files are included.

# Menu Files
Menu files make up a large portion of what you see in the main menus in Call of Duty. They can be modded in CoD4 along with
other CoDs.

# What is not included?
FastFiles. The archives are big and the map archives don't have a large code base.
The exe files, the dll files, and video files. 

# Missing things?
If I am missing some raw files, feel free to make a pull request or something.

# Legal
If Infinity Ward feels this is a copyright violation, there is no need to send a DMCA or bring me to court. 
Send me an email and I will take it down.
